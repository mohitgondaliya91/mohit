<?php
	include "connect.php";
	if(isset($_SESSION['fnm']))
	{
		header("location:home.php");
	}
?>
<form action="" method="post">
	<input type="text" name="eml" placeholder="Email"><br>
	<input type="password" name="pwd"  placeholder="Password"><br>
	<input type="submit" name="sbt">
</form>
<?php
	if(isset($_REQUEST['sbt']))
	{
		$eml=$_REQUEST['eml'];
		$pwd=$_REQUEST['pwd'];
		$sql="select * from data where email='$eml' and password='$pwd'";
		$res=mysqli_query($con,$sql);
		if(mysqli_num_rows($res) > 0)
		{
			$row=mysqli_fetch_assoc($res);
			$_SESSION['user']=$eml;
			$_SESSION['id']=$row['id'];
			$_SESSION['fnm']=$row['firstname'];
			if(isset($_SESSION['id']))
			{
				header("location:..\PERFECT/index.php");
			}
			
		}
		else
		{
			echo "WRONG USERNAME AND PASSWORD";
		}
	}
?>
<?php
	ob_start();
	ob_flush();
	ob_clean();
	session_start();
	$con=mysqli_connect("localhost","root","","project2");
	if(!$con)
	{
		echo "NOT CONNECTED";
	}
	
?>
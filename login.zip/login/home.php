<?php
	include "connect.php";
	if(!isset($_SESSION['fnm']))
	{
		header("location:login.php");
	}
?>
<h1>WELCOME ,<?=$_SESSION['fnm'];?><br>
<a href="logout.php">LOGOUT</a>